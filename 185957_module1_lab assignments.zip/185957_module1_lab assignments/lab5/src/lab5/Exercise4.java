package lab1;


	import java.util.*;
	class AgeException extends RuntimeException{
	    AgeException()
	    {
	        System.out.println("The Age should be greater than fifteen");
	    }
	}
	public class Exercise4 {
	public static void main(String args[]) {
	    Scanner sc=new Scanner(System.in);
	    System.out.println("enter age");
	    int age=sc.nextInt();
	    try {
	        if(age<15)
	            throw new AgeException();
	        else
	            System.out.println("proper age" + age);
	    }
	catch(AgeException e) {
	}
	}
	}


