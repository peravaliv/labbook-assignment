package lab5;

import java.util.Scanner;

public class Flow1 {

	public static void main(String[] arg)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the choice");
		String choice= sc.next();
		switch(choice) {
		
		case "Red": 
		System.out.println("stop");
		break;
		case "yellow":
			System.out.println("ready");
			break;
		case "green":
			System.out.println("go");
		
		
		
		}
		
	}

}
