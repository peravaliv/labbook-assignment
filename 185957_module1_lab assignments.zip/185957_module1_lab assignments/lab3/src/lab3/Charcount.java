package lab3;

import java.util.Scanner;

public class Charcount {
	public void cchar(String s)
	{
		int count=0;
		char a[]=s.toCharArray();
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a.length;j++)
			{
				if(a[i]==a[j])
				{
				count++;
			}
		}
			System.out.println("number of occurance="+count);
		}
	}


public static void main(String[] arg)
{
Charcount c=new Charcount();
Scanner sc=new Scanner(System.in);
String s=sc.next();
c.cchar(s);


}
}
